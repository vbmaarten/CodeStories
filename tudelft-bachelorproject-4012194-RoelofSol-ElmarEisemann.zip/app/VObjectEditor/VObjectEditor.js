'use strict';
/**
 * @ngdoc overview
 * @name VObjectEditor
 * @description
 * VObjectEditor module.
 */
angular.module('VObjectEditor', []);