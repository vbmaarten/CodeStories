'use strict';

/**
 * @ngdoc overview
 * @name projectManager
 * @description
 * Project manager module.
 */
angular.module('projectManager', []);
