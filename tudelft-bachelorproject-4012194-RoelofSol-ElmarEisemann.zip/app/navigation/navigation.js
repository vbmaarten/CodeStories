'use strict';
/**
 * @ngdoc overview
 * @name navigation
 * @description
 * Navigation module. This module contains the navigation for the app as well as saving.
 */
angular.module('navigation', []);
