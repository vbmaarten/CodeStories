'use strict';
/**
 * @ngdoc overview
 * @name VCodeInterpreter
 * @description
 * VCodeInterpreter module.
 */
angular.module('VCodeInterpreter', []);