'use strict';

/**
 * @ngdoc overview
 * @name projectLoader
 * @description
 * Project loader module.
 */
angular.module('projectLoader', []);
