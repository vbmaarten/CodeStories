'use strict';
/**
 * @ngdoc overview
 * @name narrator
 * @description
 * Messaging, for showing error, warning and info notifications	
 */
angular.module('notifications', []);