'use strict';

/**
 * @ngdoc overview
 * @name cast
 * @description
 * CAST module.
 */
angular.module('cast',[]);
