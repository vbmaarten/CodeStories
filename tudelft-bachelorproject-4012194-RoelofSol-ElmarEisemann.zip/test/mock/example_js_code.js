var test_script1 =  "var sum = 0;\
\
  for(var i = 0; i < 10; i++){\
  	sum += i;\
  }";